<?php include("db.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Find Your New Best Friend</title>
    <link rel="stylesheet" href="dispdog.css">
</head>
<body>
    <div class="header">
        <h1>Get a New Friend for Your Home</h1>
        <p>Give a loving home to these adorable companions waiting for you</p>
    </div>

    <?php include("display_dogs.php"); ?>
</body>
</html>